# 🛠️ GUIDE DE SETUP — BIM App

## Ce que tu as maintenant

✅ Projet restructuré en modules  
✅ PWA installable (Service Worker + manifest)  
✅ Géolocalisation intégrée  
✅ Bandeau d'installation automatique  
✅ Schéma Supabase prêt à exécuter  
✅ Mode démo fonctionnel (7 deals)  

---

## ÉTAPE 1 — Lancer en local (2 min)

```bash
# Option A : Python
cd bim-app
python3 -m http.server 8000 --directory public
# → Ouvrir http://localhost:8000

# Option B : Node.js
npx serve public
# → Ouvrir l'URL affichée

# Option C : VS Code
# Installer l'extension "Live Server", clic droit sur public/index.html → "Open with Live Server"
```

L'app tourne en mode démo, tout fonctionne.

---

## ÉTAPE 2 — Créer le projet Supabase (10 min)

### 2.1 Créer un compte
1. Aller sur **https://supabase.com**
2. Cliquer **Start your project** → se connecter avec GitHub
3. Cliquer **New project**
4. Remplir :
   - **Name** : `bim-app`
   - **Database Password** : choisir un mot de passe fort (le noter !)
   - **Region** : `West EU (Paris)` ← le plus proche
5. Cliquer **Create new project** — attendre ~2 min

### 2.2 Récupérer les clés
1. Dans le dashboard, aller dans **Settings** (icône engrenage en bas à gauche)
2. Cliquer **API** dans le menu
3. Copier :
   - **Project URL** → c'est ton `SUPABASE_URL`
   - **anon public** (sous Project API keys) → c'est ton `SUPABASE_KEY`

### 2.3 Mettre les clés dans le code
Ouvrir `public/js/config.js` et remplacer :

```javascript
SUPABASE_URL: 'https://TON-PROJET.supabase.co',    // ← coller ici
SUPABASE_KEY: 'eyJhbGciOiJIUz...',                  // ← coller ici
```

---

## ÉTAPE 3 — Créer la base de données (5 min)

### 3.1 Exécuter le schéma SQL
1. Dans le dashboard Supabase, cliquer **SQL Editor** (menu de gauche)
2. Cliquer **New query**
3. Ouvrir le fichier `supabase/schema.sql` de ton projet
4. **Tout copier-coller** dans l'éditeur SQL
5. Cliquer **Run** (bouton vert)
6. Vérifier : pas d'erreur rouge

### 3.2 Vérifier les tables
1. Cliquer **Table Editor** dans le menu
2. Tu dois voir : `merchants`, `deals`, `users`, `orders`, `order_items`, `runners`, `reviews`
3. Si tu les vois → c'est bon !

### 3.3 Créer le bucket de photos
1. Cliquer **Storage** dans le menu
2. Cliquer **New bucket**
3. Nom : `product-photos`
4. Cocher **Public bucket**
5. Cliquer **Create bucket**
6. Aller dans **Policies** du bucket
7. Cliquer **New Policy** → **For full customization**
8. Policy name : `Public read`
9. Allowed operation : **SELECT**
10. Target roles : laisser vide (tout le monde)
11. Cliquer **Save**

---

## ÉTAPE 4 — Passer en mode production (1 min)

Dans `public/js/config.js`, changer :

```javascript
DEMO_MODE: false,   // ← passer de true à false
```

Maintenant l'app charge les deals depuis Supabase au lieu des données de démo.
Les deals de démo n'apparaîtront plus — il faut publier des vrais deals via l'espace commerçant.

---

## ÉTAPE 5 — Activer l'auth Supabase (5 min)

### 5.1 Email/password
1. Dashboard → **Authentication** → **Providers**
2. Vérifier que **Email** est activé (c'est le cas par défaut)
3. Optionnel : désactiver "Confirm email" pour les tests (Settings → Auth → cocher "Enable automatic confirmation")

### 5.2 Google OAuth (optionnel, recommandé)
1. Dashboard → **Authentication** → **Providers** → **Google**
2. Activer
3. Remplir Client ID et Client Secret (depuis console.cloud.google.com)

---

## ÉTAPE 6 — Déployer sur Vercel (5 min)

### Option A : via CLI
```bash
npm i -g vercel
cd bim-app
vercel
# Suivre les instructions
# Framework : Other
# Output directory : public
# ✅ Déployé !
```

### Option B : via GitHub (recommandé)
1. Créer un repo GitHub et push le code
2. Aller sur **vercel.com** → **Add New** → **Project**
3. Importer le repo GitHub
4. Settings :
   - **Root Directory** : `public`
   - **Framework** : `Other`
5. Cliquer **Deploy**

L'app sera disponible sur `https://ton-projet.vercel.app`
Chaque push sur GitHub redéploie automatiquement.

---

## ÉTAPE 7 — Nom de domaine (optionnel, 5 min)

1. Acheter un domaine (ex: `bim-app.fr`) sur OVH, Namecheap ou Google Domains (~10€/an)
2. Vercel → **Settings** → **Domains** → Ajouter le domaine
3. Suivre les instructions DNS

---

## PROCHAINES ÉTAPES (après le lancement)

| Priorité | Tâche | Difficulté |
|----------|-------|------------|
| 🔴 Haute | Intégrer Stripe Checkout pour le paiement réel | Moyenne |
| 🔴 Haute | CGU / CGV / Mentions légales (obligatoire) | Facile |
| 🟡 Moyenne | Firebase Cloud Messaging pour les push | Moyenne |
| 🟡 Moyenne | GPS réel des runners BIM-Ride | Moyenne |
| 🟢 Basse | Analytics (Plausible ou Umami) | Facile |

---

## BESOIN D'AIDE ?

Si tu es bloqué sur une étape, reviens me voir avec le numéro de l'étape et l'erreur exacte. Je t'aide immédiatement.
