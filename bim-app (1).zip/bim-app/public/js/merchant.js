// ============================================
// BIM App — Merchant (Commerçant)
// ============================================

let dashPhotoData = null;
let dashIsRecording = false;
let dashSelectedCat = 'pret';

function showMerchantDashboard() {
  const dash = document.getElementById('merchant-dashboard');
  if (!dash) return;
  dash.style.display = 'block';
  const nameEl = document.getElementById('merchant-name-display');
  const siretEl = document.getElementById('merchant-siret-display');
  if (nameEl) nameEl.textContent = currentMerchant.name;
  if (siretEl) siretEl.textContent = 'SIRET: ' + currentMerchant.siret.slice(0, 3) + ' *** *** ' + currentMerchant.siret.slice(-3);
  updateMerchantStats();
  renderMerchantOffers();
}

function updateMerchantStats() {
  const myDeals = getMerchantDeals();
  const statOffers = document.getElementById('stat-offers');
  const statViews = document.getElementById('stat-views');
  const statSaved = document.getElementById('stat-saved');
  const offersCount = document.getElementById('my-offers-count');
  if (statOffers) statOffers.textContent = myDeals.length;
  if (statViews) statViews.textContent = myDeals.length * 47;
  const co2 = myDeals.reduce((s, d) => s + (d.co2 || 0.3), 0);
  if (statSaved) statSaved.textContent = co2.toFixed(1) + 'kg';
  if (offersCount) offersCount.textContent = myDeals.length + ' offre' + (myDeals.length > 1 ? 's' : '');
}

function getMerchantDeals() {
  if (!currentMerchant) return [];
  try {
    return JSON.parse(localStorage.getItem('bim_deals')) || [];
  } catch (e) { return []; }
}

function renderMerchantOffers() {
  const el = document.getElementById('merchant-offers-list');
  if (!el) return;
  const deals = getMerchantDeals();

  if (!deals.length) {
    el.innerHTML = '<div style="text-align:center;padding:32px;color:#475569"><div style="font-size:40px;margin-bottom:10px">📦</div><p style="font-weight:700">Aucune offre publiée</p><p style="font-size:13px;margin-top:6px">Appuyez sur "Nouvelle offre flash" pour commencer</p></div>';
    return;
  }

  el.innerHTML = deals.map(d => {
    const catEmoji = CONFIG.CATEGORIES[d.cat]?.emoji || '📦';
    const catLabel = CONFIG.CATEGORIES[d.cat]?.label || d.cat;
    const isPhoto = d.bg && d.bg.startsWith('data:');
    return `<div style="background:#1e293b;border:1px solid #334155;border-radius:16px;overflow:hidden;margin-bottom:12px;display:flex">
      <div style="width:90px;height:90px;flex-shrink:0;background:#0f172a;overflow:hidden">
        ${isPhoto ? `<img src="${d.bg}" style="width:100%;height:100%;object-fit:cover" />` : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:36px">${catEmoji}</div>`}
      </div>
      <div style="flex:1;padding:12px">
        <span style="font-size:10px;font-weight:900;background:#f97316;color:white;padding:2px 8px;border-radius:6px">${catEmoji} ${catLabel}</span>
        <p style="font-weight:900;font-size:14px;margin:4px 0 2px">${d.name}</p>
        <p style="font-size:12px;color:#64748b">${d.weight}</p>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:6px">
          <div><span style="font-size:18px;font-weight:900;color:#34d399">${d.price.toFixed(2)}€</span>
          <span style="font-size:11px;color:#475569;text-decoration:line-through">${d.orig}€</span></div>
          <button onclick="deleteSavedDeal(${d.id})" style="background:#0f172a;border:1px solid #334155;border-radius:8px;padding:6px 10px;color:#ef4444;cursor:pointer;font-size:14px;font-weight:700">🗑</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function showNewOfferPanel() {
  const panel = document.getElementById('new-offer-panel');
  if (panel) {
    panel.style.display = 'block';
    panel.scrollIntoView({ behavior: 'smooth' });
  }
}

function hideNewOfferPanel() {
  const panel = document.getElementById('new-offer-panel');
  if (panel) panel.style.display = 'none';
  resetDashForm();
}

// ---- PHOTO ----

function handleDashPhoto(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function (e) {
    dashPhotoData = e.target.result;
    const img = document.getElementById('dash-photo-img');
    if (img) { img.src = e.target.result; img.style.display = 'block'; }
    const placeholder = document.getElementById('dash-photo-placeholder');
    if (placeholder) placeholder.style.display = 'none';
    // Simuler analyse IA
    const scanning = document.getElementById('dash-ai-scanning');
    if (scanning) scanning.style.display = 'flex';
    setTimeout(() => {
      if (scanning) scanning.style.display = 'none';
      const result = document.getElementById('dash-ai-result');
      if (result) {
        result.style.display = 'block';
        result.textContent = '🤖 Produit identifié - Aspect visuel optimal - Fraîcheur A+';
      }
    }, 1500);
  };
  reader.readAsDataURL(file);
}

// ---- VOCAL ----

function toggleDashMic() {
  const btn = document.getElementById('dash-mic-btn');
  const hint = document.getElementById('dash-mic-hint');
  const transcript = document.getElementById('dash-transcript');

  if (dashIsRecording) {
    if (window._dashRecognition) window._dashRecognition.stop();
    return;
  }

  if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
    if (hint) hint.textContent = 'Micro non disponible — remplissez manuellement';
    return;
  }

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  window._dashRecognition = new SR();
  window._dashRecognition.lang = 'fr-FR';
  window._dashRecognition.continuous = false;
  window._dashRecognition.interimResults = false;

  window._dashRecognition.onstart = () => {
    dashIsRecording = true;
    if (btn) { btn.textContent = 'STOP'; btn.style.background = '#ef4444'; btn.style.fontSize = '14px'; }
    if (hint) hint.textContent = 'Parlez... appuyez STOP quand terminé';
  };

  window._dashRecognition.onresult = (e) => {
    const result = e.results[e.results.length - 1];
    if (result.isFinal && transcript) {
      transcript.textContent = result[0].transcript;
    }
  };

  window._dashRecognition.onend = () => {
    dashIsRecording = false;
    if (btn) { btn.textContent = '🎤'; btn.style.background = '#f97316'; btn.style.fontSize = '26px'; }
    if (hint) hint.textContent = 'Note vocale enregistrée !';
    // Parse transcript into fields
    const text = transcript?.textContent;
    if (text) parseDashVoice(text);
  };

  window._dashRecognition.onerror = (e) => {
    dashIsRecording = false;
    if (btn) { btn.textContent = '🎤'; btn.style.background = '#f97316'; btn.style.fontSize = '26px'; }
    if (hint) hint.textContent = e.error === 'not-allowed' ? 'Autorisez le micro' : 'Erreur — remplissez manuellement';
  };

  window._dashRecognition.start();
}

function parseDashVoice(text) {
  // Simple parsing
  const cat = detectCategory(text);
  dashSelectedCat = cat;
  // Try to extract numbers for price/discount
  const numbers = text.match(/\d+([.,]\d+)?/g);
  if (numbers && numbers.length >= 1) {
    const nameField = document.getElementById('dash-name');
    if (nameField && !nameField.value) nameField.value = text.split(/\d/)[0].trim();
  }
}

// ---- PUBLISH ----

function publishDashOffer() {
  const name = document.getElementById('dash-name')?.value.trim();
  const orig = parseFloat(document.getElementById('dash-orig')?.value);
  const discount = parseInt(document.getElementById('dash-discount')?.value);
  const qty = document.getElementById('dash-qty')?.value.trim() || '1 lot';

  if (!name) { showToast('Nom du produit requis'); return; }
  if (!orig || orig <= 0) { showToast('Prix de base requis'); return; }
  if (!discount || discount <= 0) { showToast('Remise requise'); return; }

  const flashPrice = orig * (1 - discount / 100);
  const cat = dashSelectedCat;
  const catEmoji = CONFIG.CATEGORIES[cat]?.emoji || '📦';

  const deal = {
    id: Date.now(),
    cat,
    name,
    merchant: currentMerchant?.name || 'Mon commerce',
    origin: 'Local',
    discount,
    price: Math.round(flashPrice * 100) / 100,
    orig,
    weight: qty,
    expiry: "Aujourd'hui",
    timer: '4h 00m',
    ai: dashPhotoData ? 'Produit identifié - Aspect visuel optimal' : null,
    badge: 'FLASH',
    badgeColor: CONFIG.CATEGORIES[cat]?.color || '#F97316',
    co2: 0.3,
    bg: dashPhotoData || '',
    photo: dashPhotoData || '',
    desc: '',
  };

  // Save locally
  DEALS.unshift(deal);
  saveDealToStorage(deal);

  // Save to Supabase if available
  if (supabaseClient && !CONFIG.DEMO_MODE) {
    saveDealToDB({
      merchant_id: currentMerchant?.supabaseId,
      name: deal.name,
      category: deal.cat,
      original_price: deal.orig,
      flash_price: deal.price,
      quantity: deal.weight,
      photo_url: null, // TODO: upload photo to storage
      badge: deal.badge,
      badge_color: deal.badgeColor,
      expires_at: new Date(Date.now() + 4 * 3600000).toISOString(),
    });
  }

  hideNewOfferPanel();
  updateMerchantStats();
  renderMerchantOffers();
  renderDeal();
  showToast('⚡ Offre publiée : ' + name);
}

function saveDealToStorage(deal) {
  try {
    let deals = JSON.parse(localStorage.getItem('bim_deals')) || [];
    deals.unshift(deal);
    localStorage.setItem('bim_deals', JSON.stringify(deals));
  } catch (e) {}
}

function deleteSavedDeal(id) {
  DEALS = DEALS.filter(d => d.id !== id);
  try {
    let deals = JSON.parse(localStorage.getItem('bim_deals')) || [];
    deals = deals.filter(d => d.id !== id);
    localStorage.setItem('bim_deals', JSON.stringify(deals));
  } catch (e) {}
  renderMerchantOffers();
  updateMerchantStats();
  dismissed = dismissed.filter(x => x !== id);
  renderDeal();
  showToast('Offre supprimée');
}

function setDashCat(btn, cat) {
  dashSelectedCat = cat;
  document.querySelectorAll('.dash-cat-btn').forEach(b => { b.style.opacity = '0.4'; b.style.boxShadow = 'none'; });
  btn.style.opacity = '1';
  btn.style.boxShadow = '0 0 0 2px #f97316';
}

function calcDashFlash() {
  const orig = parseFloat(document.getElementById('dash-orig')?.value) || 0;
  const disc = parseInt(document.getElementById('dash-discount')?.value) || 0;
  const preview = document.getElementById('dash-flash-preview');
  const val = document.getElementById('dash-flash-val');
  if (orig > 0 && disc > 0) {
    const flash = orig * (1 - disc / 100);
    if (preview) preview.style.display = 'flex';
    if (val) val.textContent = flash.toFixed(2) + '€';
  } else {
    if (preview) preview.style.display = 'none';
  }
}

function resetDashForm() {
  dashPhotoData = null;
  dashIsRecording = false;
  const img = document.getElementById('dash-photo-img');
  const placeholder = document.getElementById('dash-photo-placeholder');
  if (img) img.style.display = 'none';
  if (placeholder) placeholder.style.display = 'block';
  const aiResult = document.getElementById('dash-ai-result');
  const aiScan = document.getElementById('dash-ai-scanning');
  if (aiResult) aiResult.style.display = 'none';
  if (aiScan) aiScan.style.display = 'none';
  ['dash-name', 'dash-orig', 'dash-discount', 'dash-qty'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  const preview = document.getElementById('dash-flash-preview');
  if (preview) preview.style.display = 'none';
  dashSelectedCat = 'pret';
}
