// ============================================
// BIM App — Service Worker
// Cache-first pour les assets, network-first pour les API
// ============================================

const CACHE_NAME = 'bim-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/css/styles.css',
  '/js/config.js',
  '/js/supabase-client.js',
  '/js/app.js',
  '/js/deals.js',
  '/js/cart.js',
  '/js/auth.js',
  '/js/merchant.js',
  '/js/bimride.js',
  '/js/notifications.js',
  '/logo.png',
  '/manifest.json',
];

// Install — cache tous les assets statiques
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[SW] Caching static assets');
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

// Activate — nettoyer les anciens caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// Fetch — stratégie mixte
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // API Supabase & externes → network-first
  if (url.hostname !== location.hostname || url.pathname.startsWith('/rest/') || url.pathname.startsWith('/auth/')) {
    event.respondWith(
      fetch(event.request).catch(() => caches.match(event.request))
    );
    return;
  }

  // Images Unsplash → cache-first avec fallback
  if (url.hostname.includes('unsplash') || url.hostname.includes('randomuser')) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          return response;
        }).catch(() => new Response('', { status: 404 }));
      })
    );
    return;
  }

  // Assets statiques → cache-first, puis network
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      });
    })
  );
});

// Push notifications
self.addEventListener('push', event => {
  const data = event.data?.json() || {};
  event.waitUntil(
    self.registration.showNotification(data.title || 'BIM', {
      body: data.body || 'Nouvelle offre flash !',
      icon: '/logo.png',
      badge: '/logo.png',
      tag: 'bim-' + Date.now(),
      data: { url: data.url || '/' }
    })
  );
});

// Click sur notification → ouvrir l'app
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then(list => {
      if (list.length > 0) {
        list[0].focus();
        return list[0].navigate(event.notification.data?.url || '/');
      }
      return clients.openWindow(event.notification.data?.url || '/');
    })
  );
});
