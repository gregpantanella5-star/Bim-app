-- ============================================
-- BIM App — Schéma Supabase (PostgreSQL)
-- À exécuter dans : Supabase Dashboard > SQL Editor
-- ============================================

-- 1. Extension PostGIS pour la géolocalisation
CREATE EXTENSION IF NOT EXISTS postgis;

-- ============================================
-- TABLES
-- ============================================

-- MERCHANTS (commerçants)
CREATE TABLE merchants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  siret VARCHAR(14) UNIQUE NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('viande','poisson','cave','primeur','laitier','pret','boulangerie','traiteur','autre')),
  description TEXT,
  phone VARCHAR(20),
  email TEXT,
  address TEXT,
  city TEXT DEFAULT 'Fayence',
  location GEOGRAPHY(POINT, 4326),  -- coordonnées GPS
  photo_url TEXT,
  is_verified BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- DEALS (offres flash)
CREATE TABLE deals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id UUID REFERENCES merchants(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL CHECK (category IN ('viande','poisson','cave','primeur','laitier','pret','boulangerie','traiteur','autre')),
  original_price DECIMAL(10,2) NOT NULL,
  flash_price DECIMAL(10,2) NOT NULL,
  discount_percent INTEGER GENERATED ALWAYS AS (
    CASE WHEN original_price > 0 
      THEN ROUND(((original_price - flash_price) / original_price) * 100)
      ELSE 0 
    END
  ) STORED,
  quantity TEXT,                    -- ex: "2 kg", "12 x 75cl"
  photo_url TEXT,
  ai_analysis TEXT,                -- résultat de l'analyse IA de la photo
  badge TEXT DEFAULT 'FLASH',      -- FLASH, BIM TERROIR, ENCHERE, PRIX CHOC
  badge_color VARCHAR(7) DEFAULT '#F97316',
  co2_saved DECIMAL(5,2) DEFAULT 0.3,
  origin TEXT,                     -- VAR, AOP, Local, etc.
  expires_at TIMESTAMPTZ NOT NULL, -- date/heure d'expiration de l'offre
  is_active BOOLEAN DEFAULT true,
  views_count INTEGER DEFAULT 0,
  cart_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- USERS (clients / acheteurs)
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name TEXT NOT NULL,
  last_name TEXT,
  email TEXT UNIQUE NOT NULL,
  phone VARCHAR(20),
  location GEOGRAPHY(POINT, 4326),
  search_radius_km INTEGER DEFAULT 10,
  favorite_categories TEXT[] DEFAULT '{}',
  favorite_products TEXT[] DEFAULT '{}',
  push_token TEXT,
  notif_enabled BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ORDERS (commandes)
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT UNIQUE NOT NULL, -- ex: BIM-12345
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  merchant_id UUID REFERENCES merchants(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN (
    'pending',        -- créée, en attente de paiement
    'paid',           -- payée
    'preparing',      -- en préparation chez le commerçant
    'ready',          -- prête, en attente de runner
    'delivering',     -- en cours de livraison
    'delivered',      -- livrée
    'cancelled'       -- annulée
  )),
  subtotal DECIMAL(10,2) NOT NULL,
  discount_total DECIMAL(10,2) DEFAULT 0,
  delivery_fee DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) NOT NULL,
  payment_method TEXT,              -- card, apple_pay, google_pay
  stripe_payment_id TEXT,
  delivery_address TEXT,
  delivery_location GEOGRAPHY(POINT, 4326),
  runner_id UUID REFERENCES runners(id) ON DELETE SET NULL,
  notes TEXT,
  paid_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- ORDER_ITEMS (articles de commande)
CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  deal_id UUID REFERENCES deals(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  total DECIMAL(10,2) NOT NULL
);

-- RUNNERS (livreurs BIM-Ride)
CREATE TABLE runners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone VARCHAR(20),
  email TEXT,
  photo_url TEXT,
  bio TEXT,
  vehicle_type TEXT DEFAULT 'velo' CHECK (vehicle_type IN ('velo','scooter','voiture','marche')),
  is_available BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  current_location GEOGRAPHY(POINT, 4326),
  current_route TEXT,
  rating DECIMAL(2,1) DEFAULT 5.0,
  total_deliveries INTEGER DEFAULT 0,
  total_co2_saved DECIMAL(6,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- REVIEWS (avis sur les runners)
CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  runner_id UUID REFERENCES runners(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  order_id UUID REFERENCES orders(id) ON DELETE SET NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================
-- INDEX pour la performance
-- ============================================

CREATE INDEX idx_deals_category ON deals(category);
CREATE INDEX idx_deals_active ON deals(is_active, expires_at);
CREATE INDEX idx_deals_merchant ON deals(merchant_id);
CREATE INDEX idx_deals_created ON deals(created_at DESC);
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_merchant ON orders(merchant_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_runners_available ON runners(is_available, is_active);
CREATE INDEX idx_reviews_runner ON reviews(runner_id);

-- Index géographiques
CREATE INDEX idx_merchants_location ON merchants USING GIST(location);
CREATE INDEX idx_runners_location ON runners USING GIST(current_location);

-- ============================================
-- FONCTIONS
-- ============================================

-- Générer un numéro de commande unique
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TRIGGER AS $$
BEGIN
  NEW.order_number := 'BIM-' || LPAD(FLOOR(RANDOM() * 99999 + 10000)::TEXT, 5, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_order_number
  BEFORE INSERT ON orders
  FOR EACH ROW
  WHEN (NEW.order_number IS NULL)
  EXECUTE FUNCTION generate_order_number();

-- Désactiver automatiquement les deals expirés
CREATE OR REPLACE FUNCTION deactivate_expired_deals()
RETURNS void AS $$
BEGIN
  UPDATE deals SET is_active = false WHERE expires_at < now() AND is_active = true;
END;
$$ LANGUAGE plpgsql;

-- Mettre à jour la note moyenne du runner après un avis
CREATE OR REPLACE FUNCTION update_runner_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE runners SET 
    rating = (SELECT ROUND(AVG(rating)::numeric, 1) FROM reviews WHERE runner_id = NEW.runner_id)
  WHERE id = NEW.runner_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_rating
  AFTER INSERT ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_runner_rating();

-- Chercher les deals à proximité
CREATE OR REPLACE FUNCTION nearby_deals(
  user_lat DOUBLE PRECISION,
  user_lng DOUBLE PRECISION,
  radius_km INTEGER DEFAULT 10,
  cat TEXT DEFAULT NULL
)
RETURNS TABLE (
  deal_id UUID,
  deal_name TEXT,
  merchant_name TEXT,
  category TEXT,
  flash_price DECIMAL,
  original_price DECIMAL,
  discount INTEGER,
  distance_km DOUBLE PRECISION,
  photo TEXT,
  expires TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    d.id,
    d.name,
    m.name,
    d.category,
    d.flash_price,
    d.original_price,
    d.discount_percent,
    ROUND((ST_Distance(
      m.location,
      ST_SetSRID(ST_MakePoint(user_lng, user_lat), 4326)::geography
    ) / 1000)::numeric, 1)::double precision AS dist_km,
    d.photo_url,
    d.expires_at
  FROM deals d
  JOIN merchants m ON d.merchant_id = m.id
  WHERE d.is_active = true
    AND d.expires_at > now()
    AND (cat IS NULL OR d.category = cat)
    AND ST_DWithin(
      m.location,
      ST_SetSRID(ST_MakePoint(user_lng, user_lat), 4326)::geography,
      radius_km * 1000
    )
  ORDER BY dist_km ASC, d.created_at DESC;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================

ALTER TABLE merchants ENABLE ROW LEVEL SECURITY;
ALTER TABLE deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE runners ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- DEALS : tout le monde peut lire les deals actifs
CREATE POLICY "Deals visibles par tous" ON deals
  FOR SELECT USING (is_active = true AND expires_at > now());

-- DEALS : seul le commerçant propriétaire peut créer/modifier
CREATE POLICY "Commerçant gère ses deals" ON deals
  FOR ALL USING (
    merchant_id IN (SELECT id FROM merchants WHERE user_id = auth.uid())
  );

-- MERCHANTS : profil public en lecture
CREATE POLICY "Profils commerçants publics" ON merchants
  FOR SELECT USING (is_active = true);

-- MERCHANTS : un commerçant ne modifie que son profil
CREATE POLICY "Commerçant gère son profil" ON merchants
  FOR UPDATE USING (user_id = auth.uid());

-- USERS : un utilisateur ne voit que son propre profil
CREATE POLICY "Utilisateur voit son profil" ON users
  FOR ALL USING (user_id = auth.uid());

-- ORDERS : le client voit ses commandes
CREATE POLICY "Client voit ses commandes" ON orders
  FOR SELECT USING (
    user_id IN (SELECT id FROM users WHERE user_id = auth.uid())
  );

-- ORDERS : le commerçant voit les commandes qui le concernent
CREATE POLICY "Commerçant voit ses commandes" ON orders
  FOR SELECT USING (
    merchant_id IN (SELECT id FROM merchants WHERE user_id = auth.uid())
  );

-- RUNNERS : profils publics en lecture
CREATE POLICY "Runners profils publics" ON runners
  FOR SELECT USING (is_active = true);

-- RUNNERS : un runner ne modifie que son profil
CREATE POLICY "Runner gère son profil" ON runners
  FOR UPDATE USING (user_id = auth.uid());

-- REVIEWS : tout le monde peut lire
CREATE POLICY "Avis publics" ON reviews
  FOR SELECT USING (true);

-- REVIEWS : un client connecté peut écrire un avis
CREATE POLICY "Client écrit un avis" ON reviews
  FOR INSERT WITH CHECK (
    user_id IN (SELECT id FROM users WHERE user_id = auth.uid())
  );

-- ============================================
-- REALTIME (activer les notifications temps réel)
-- ============================================

ALTER PUBLICATION supabase_realtime ADD TABLE deals;
ALTER PUBLICATION supabase_realtime ADD TABLE orders;
ALTER PUBLICATION supabase_realtime ADD TABLE runners;

-- ============================================
-- CRON JOB : désactiver les deals expirés toutes les 5 min
-- (nécessite l'extension pg_cron dans Supabase)
-- ============================================
-- SELECT cron.schedule('deactivate-expired-deals', '*/5 * * * *', 'SELECT deactivate_expired_deals()');
