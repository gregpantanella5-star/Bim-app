# 🟢 BIM — Le Cercle Vertueux Alimentaire

Application mobile-first d'offres flash anti-gaspi pour les commerçants locaux.

---

## 📁 Structure du projet

```
bim-app/
├── public/                    ← DOSSIER À DÉPLOYER
│   ├── index.html             ← Page principale
│   ├── manifest.json          ← PWA manifest
│   ├── logo.png               ← Logo BIM
│   ├── css/
│   │   └── styles.css         ← Tous les styles
│   └── js/
│       ├── config.js          ← Configuration & constantes
│       ├── supabase-client.js ← Connexion Supabase & helpers
│       ├── app.js             ← Init, navigation, swipe
│       ├── deals.js           ← Feed, cartes, filtres
│       ├── cart.js            ← Panier, paiement
│       ├── auth.js            ← Auth client + commerçant
│       ├── merchant.js        ← Dashboard commerçant
│       ├── bimride.js         ← BIM-Ride carte & runners
│       └── notifications.js   ← Push notifications
├── src/                       ← Sources de référence (même contenu que public/js et css)
├── supabase/
│   └── schema.sql             ← Schéma complet de la BDD
└── README.md
```

---

## 🚀 Démarrage rapide

### 1. Cloner le projet

```bash
git clone <votre-repo>
cd bim-app
```

### 2. Lancer en local

Aucune installation requise ! Ouvrez simplement `public/index.html` dans un navigateur,
ou utilisez un serveur local :

```bash
# Avec Python
python3 -m http.server 8000 --directory public

# Avec Node.js (npx)
npx serve public

# Avec VS Code : installer l'extension "Live Server" et cliquer "Go Live"
```

### 3. Mode démo vs production

Dans `src/js/config.js`, le flag `DEMO_MODE` contrôle le comportement :

- `DEMO_MODE: true` → Charges les 7 deals de démo, pas besoin de Supabase
- `DEMO_MODE: false` → Charge les deals depuis Supabase uniquement

---

## 🗄️ Setup Supabase (base de données)

### 1. Créer un projet Supabase

1. Aller sur [supabase.com](https://supabase.com)
2. Créer un nouveau projet (gratuit)
3. Récupérer l'URL et la clé publique (anon key)
4. Les mettre dans `src/js/config.js`

### 2. Exécuter le schéma

1. Aller dans **SQL Editor** dans le dashboard Supabase
2. Coller le contenu de `supabase/schema.sql`
3. Exécuter

Cela crée :
- **merchants** — commerçants
- **deals** — offres flash
- **users** — clients
- **orders** — commandes
- **order_items** — articles de commande
- **runners** — livreurs BIM-Ride
- **reviews** — avis

Plus : index, fonctions PostGIS, Row Level Security (RLS), et Realtime.

### 3. Créer un bucket Storage

1. Dashboard Supabase → **Storage**
2. Créer un bucket `product-photos` (public)
3. Politique : lecture publique, écriture authentifiée

---

## 💳 Setup Stripe (paiement) — Phase 2

1. Créer un compte sur [stripe.com](https://stripe.com)
2. Récupérer les clés API (mode test d'abord)
3. Créer une Edge Function Supabase pour le checkout :

```javascript
// supabase/functions/create-checkout/index.ts
import Stripe from 'stripe';
const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!);

Deno.serve(async (req) => {
  const { items, orderId } = await req.json();
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: items.map(item => ({
      price_data: {
        currency: 'eur',
        product_data: { name: item.name },
        unit_amount: Math.round(item.price * 100),
      },
      quantity: item.qty,
    })),
    mode: 'payment',
    success_url: `https://votre-domaine.com/?order=${orderId}&status=success`,
    cancel_url: `https://votre-domaine.com/?status=cancelled`,
  });
  return new Response(JSON.stringify({ url: session.url }));
});
```

---

## 🌐 Déploiement Vercel

```bash
# Installer Vercel CLI
npm i -g vercel

# Déployer
cd bim-app
vercel --prod

# Le dossier public/ sera servi automatiquement
```

Ou connecter le repo Git à Vercel pour le déploiement automatique.

---

## 📋 Feuille de route

| Phase | Description | Statut |
|-------|-------------|--------|
| 0 | Restructurer le code (ce fichier) | ✅ Fait |
| 1 | Backend Supabase (schéma, auth, CRUD) | 🔧 En cours |
| 2 | Paiement Stripe | ⏳ À faire |
| 3 | Notifications push (Firebase/OneSignal) | ⏳ À faire |
| 4 | BIM-Ride GPS réel | ⏳ À faire |
| 5 | Sécurité, RGPD, tests | ⏳ À faire |
| 6 | Lancement MVP | ⏳ À faire |

---

## 📄 Licence

Projet privé — BIM © 2026
